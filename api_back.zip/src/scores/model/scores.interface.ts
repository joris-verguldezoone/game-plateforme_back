export interface ScoresInterface {
    id?:number,
    score?:number,
    id_user?:number,
    id_partie?:number
}