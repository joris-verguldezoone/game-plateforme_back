export class CreateScoreDto {}
