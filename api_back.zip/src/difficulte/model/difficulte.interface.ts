export interface DifficulteInterface {
    id?:number,
    difficulte?:string,
    multiplicateurscore?:number
}