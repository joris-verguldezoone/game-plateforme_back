export class CreateDifficulteDto {}
