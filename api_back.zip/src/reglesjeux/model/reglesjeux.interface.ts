export interface ReglesjeuxInterface {
    id?:number,
    idjeux?:number,
    nomregle?:string,
    regle?:string,
    iddifficulte?:number,
    nbjoueur_min?:number,
    nbjoueur_max?:number,
}