export class CreateReglesjeuxDto {}
