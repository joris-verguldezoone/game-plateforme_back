export interface AvatarInterface{
    id?:number,
    description?:string,
    image?:string,
}