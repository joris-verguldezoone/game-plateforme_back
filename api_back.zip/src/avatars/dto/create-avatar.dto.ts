export class CreateAvatarDto {}
