export interface TypesInterface{
    id?:number,
    type_de_jeux?:string,
    nb_de_jeux?:number,
    nb_cartes?:number,
    type_de_carte?:string;
}