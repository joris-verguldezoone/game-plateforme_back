export interface JeuxInterface{
    id?:number;
    nom?:string;
    idtype?:number;
}