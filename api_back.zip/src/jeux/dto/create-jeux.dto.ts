export class CreateJeuxDto {}
