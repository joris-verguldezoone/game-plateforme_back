export interface PartieusersInterface{
    id?:number,
    id_user?:number,
    id_partie?:number,
    statut?:number,
}