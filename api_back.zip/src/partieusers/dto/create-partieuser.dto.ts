export class CreatePartieuserDto {}
