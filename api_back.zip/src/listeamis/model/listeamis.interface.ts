export interface ListeamisInterface{
    id?:number,
    iduser?:number,
    iduser2?:number,
    statut?:number
}