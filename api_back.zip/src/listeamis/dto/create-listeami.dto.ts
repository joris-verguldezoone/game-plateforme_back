export class CreateListeamiDto {}
