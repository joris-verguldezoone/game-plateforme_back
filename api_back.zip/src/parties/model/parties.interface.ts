export interface PartiesInterface{
    id?:number,
    nbjoueurs?:number,
    iddifficulte?:number,
    idjeux?:number,
    createdat?: Date,
    finishedat?:Date,
}