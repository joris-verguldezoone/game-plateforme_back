export class CreatePartyDto {}
